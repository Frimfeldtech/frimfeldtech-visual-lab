import React, { useState, useCallback } from 'react';
import { Screen, SubscriptionPlan } from './types';
import WelcomeScreen from './components/WelcomeScreen';
import InputScreen from './components/InputScreen';
import ResultScreen from './components/ResultScreen';
import CameraView from './components/CameraView';
import SubscriptionScreen from './components/SubscriptionScreen';
import PaymentModal from './components/PaymentModal';
import { generatePalmReading } from './services/geminiService';
import { LogoIcon } from './components/icons';
import { useLanguage } from './context/LanguageContext';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.Welcome);
  const [lifeLine, setLifeLine] = useState('');
  const [headLine, setHeadLine] = useState('');
  const [handImage, setHandImage] = useState<string | null>(null);
  const [reading, setReading] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [plan, setPlan] = useState<SubscriptionPlan>('free');
  const [isPaymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedPlanForPayment, setSelectedPlanForPayment] = useState<SubscriptionPlan | null>(null);
  
  const { language, t } = useLanguage();

  const handleStart = () => {
    setCurrentScreen(Screen.Subscription);
  };

  const handleSelectPlan = (selectedPlan: SubscriptionPlan) => {
    if (selectedPlan === 'free') {
      setPlan('free');
      setCurrentScreen(Screen.Input);
    } else {
      setSelectedPlanForPayment(selectedPlan);
      setPaymentModalOpen(true);
    }
  };

  const handlePaymentSuccess = () => {
    if (selectedPlanForPayment) {
      setPlan(selectedPlanForPayment);
      setPaymentModalOpen(false);
      setCurrentScreen(Screen.Input);
    }
  };

  const handleOpenCamera = () => {
    setCurrentScreen(Screen.Camera);
  };

  const handleCapture = (imageDataUrl: string) => {
    setHandImage(imageDataUrl);
    setLifeLine('');
    setHeadLine('');
    setCurrentScreen(Screen.Input);
  };

  const handleClearImage = () => {
    setHandImage(null);
  };

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      let result;
      if (handImage) {
        const [header, base64Data] = handImage.split(',');
        if (!base64Data) {
          throw new Error('Invalid image data URL');
        }
        const mimeType = header.match(/:(.*?);/)?.[1] || 'image/jpeg';
        result = await generatePalmReading({
          handImage: { mimeType, data: base64Data },
        }, language, plan);
      } else {
        if (!lifeLine.trim() || !headLine.trim()) {
          setError(t('errorBothLines'));
          setIsLoading(false);
          return;
        }
        result = await generatePalmReading({ lifeLine, headLine }, language, plan);
      }
      setReading(result);
      setCurrentScreen(Screen.Result);
    } catch (err) {
      setError(t('errorReading'));
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [lifeLine, headLine, handImage, language, plan, t]);

  const handleReset = () => {
    setLifeLine('');
    setHeadLine('');
    setHandImage(null);
    setReading('');
    setError(null);
    setPlan('free');
    setCurrentScreen(Screen.Welcome);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case Screen.Welcome:
        return <WelcomeScreen onStart={handleStart} />;
      case Screen.Subscription:
        return <SubscriptionScreen onSelectPlan={handleSelectPlan} />;
      case Screen.Input:
        return (
          <InputScreen
            lifeLine={lifeLine}
            setLifeLine={setLifeLine}
            headLine={headLine}
            setHeadLine={setHeadLine}
            onGenerate={handleGenerate}
            isLoading={isLoading}
            error={error}
            handImage={handImage}
            onOpenCamera={handleOpenCamera}
            onClearImage={handleClearImage}
          />
        );
      case Screen.Camera:
        return <CameraView onCapture={handleCapture} onClose={() => setCurrentScreen(Screen.Input)} />;
      case Screen.Result:
        return <ResultScreen reading={reading} onReset={handleReset} />;
      default:
        return <WelcomeScreen onStart={handleStart} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-deep-purple to-brand-purple text-brand-light-gold font-sans flex flex-col items-center justify-center p-4 sm:p-6 md:p-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMCIgaGVpZ2h0PSIzMCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idHJhbnNwYXJlbnQiLz48Y2lyY2xlIGN4PSIxNSIgY3k9IjE1IiByPSIxIiBmaWxsPSJyZ2JhKDc0LCA2MywgMTA5LCAwLjIpIi8+PC9zdmc+')] opacity-50"></div>
      
      {isPaymentModalOpen && selectedPlanForPayment && (
        <PaymentModal 
          planId={selectedPlanForPayment}
          onClose={() => setPaymentModalOpen(false)}
          onSuccess={handlePaymentSuccess}
        />
      )}

      <main className="w-full max-w-md md:max-w-4xl mx-auto z-10 animate-fade-in">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-4">
            <LogoIcon className="w-12 h-12 text-brand-gold" />
            <h1 className="text-4xl md:text-5xl font-serif text-white" style={{ fontFamily: "'Playfair Display', serif" }}>
              {t('appName')}
            </h1>
          </div>
        </header>
        <div className="bg-brand-purple/50 backdrop-blur-sm rounded-2xl shadow-2xl shadow-brand-deep-purple/50 p-6 md:p-10 border border-brand-light-purple/30 relative">
          {renderScreen()}
        </div>
      </main>
    </div>
  );
};

export default App;