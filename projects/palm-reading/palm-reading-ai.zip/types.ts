export enum Screen {
  Welcome,
  Subscription,
  Input,
  Result,
  Camera,
}

export type Language = 'en' | 'es';

export type SubscriptionPlan = 'free' | 'basic' | '6-month' | '1-year';

export interface Plan {
  id: SubscriptionPlan;
  nameKey: string;
  price: string;
  priceDetailsKey: string;
  features: string[];
}