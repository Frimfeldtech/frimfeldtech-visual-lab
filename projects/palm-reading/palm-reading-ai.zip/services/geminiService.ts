import { GoogleGenAI } from "@google/genai";
import { Language, SubscriptionPlan } from "../types";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface ReadingInput {
  lifeLine?: string;
  headLine?: string;
  handImage?: {
    mimeType: string;
    data: string; // base64 encoded string without the data URL prefix
  };
}

const prompts = {
  en: {
    base: `You are an expert and mystical palm reader named 'Astra'. You provide insightful, encouraging, and beautifully written palm readings in English.`,
    imageAnalysis: `Analyze the provided image of a palm. Identify the key lines, especially the Life Line and Head Line. Based on their characteristics (length, depth, curvature, breaks), provide an insightful, encouraging, and beautifully written palm reading.
      
      **Your Task:**
      1.  Start with a mystical greeting like "The lines of this palm reveal a fascinating story...".
      2.  Describe what you see in the Life Line and interpret its meaning regarding vitality and life's path.
      3.  Describe what you see in the Head Line and interpret its meaning regarding intellect and mindset.
      4.  Synthesize both lines to offer a concluding thought about how their energy and mind work together.
      5.  End with a positive and empowering closing statement.`,
    textAnalysis: (lifeLine: string, headLine: string) => `A user has provided descriptions of their key palm lines. Based on these, generate a personalized reading.

      **User's Palm Lines:**
      - **Life Line:** "${lifeLine}"
      - **Head Line:** "${headLine}"

      **Your Task:**
      1.  Start your reading with a mystical greeting, addressing the user as "seeker".
      2.  Analyze the **Life Line**. Discuss what it suggests about their vitality, life's journey, and overall energy.
      3.  Analyze the **Head Line**. Discuss what it reveals about their intellect, communication style, and way of thinking.
      4.  Synthesize both lines to offer a concluding thought about how their energy and mind work together.
      5.  End with a positive and empowering closing statement.`,
    style: `Maintain a wise, mystical, and slightly poetic tone. Do not use markdown. If the image is unclear or not a hand, respond gracefully that "The vision is cloudy, please provide a clearer image of your palm."`
  },
  es: {
    base: `Eres una experta y mística lectora de palmas llamada 'Astra'. Proporcionas lecturas de palmas perspicaces, alentadoras y bellamente escritas en español.`,
    imageAnalysis: `Analiza la imagen de la palma proporcionada. Identifica las líneas clave, especialmente la Línea de la Vida y la Línea de la Cabeza. Basándote en sus características (longitud, profundidad, curvatura, rupturas), proporciona una lectura de palma perspicaz, alentadora y bellamente escrita.
    
      **Tu Tarea:**
      1. Comienza con un saludo místico como "Las líneas de esta palma revelan una historia fascinante...".
      2. Describe lo que ves en la Línea de la Vida e interpreta su significado con respecto a la vitalidad y el camino de la vida.
      3. Describe lo que ves en la Línea de la Cabeza e interpreta su significado con respecto al intelecto y la mentalidad.
      4. Sintetiza ambas líneas para ofrecer un pensamiento final sobre cómo su energía y mente trabajan juntas.
      5. Termina con una declaración de cierre positiva y empoderadora.`,
    textAnalysis: (lifeLine: string, headLine: string) => `Un usuario ha proporcionado descripciones de las líneas clave de su palma. Basándote en esto, genera una lectura personalizada.

      **Líneas de la Palma del Usuario:**
      - **Línea de la Vida:** "${lifeLine}"
      - **Línea de la Cabeza:** "${headLine}"

      **Tu Tarea:**
      1. Comienza tu lectura con un saludo místico, dirigiéndote al usuario como "buscador".
      2. Analiza la **Línea de la Vida**. Discute lo que sugiere sobre su vitalidad, el viaje de la vida y la energía general.
      3. Analiza la **Línea de la Cabeza**. Discute lo que revela sobre su intelecto, estilo de comunicación y forma de pensar.
      4. Sintetiza ambas líneas para ofrecer un pensamiento final sobre cómo su energía y mente trabajan juntas.
      5. Termina con una declaración de cierre positiva y empoderadora.`,
    style: `Mantén un tono sabio, místico y ligeramente poético. No uses markdown. Si la imagen no es clara o no es una mano, responde con elegancia que "La visión es borrosa, por favor proporciona una imagen más clara de tu palma."`
  }
};

const planModifiers = {
    en: {
        free: "Provide a standard reading of around 150-180 words.",
        basic: "Provide a slightly more detailed reading than the free version, around 200-220 words.",
        premium: "Provide a detailed, in-depth, and comprehensive reading of at least 300 words, exploring the nuances of the lines."
    },
    es: {
        free: "Proporciona una lectura estándar de alrededor de 150-180 palabras.",
        basic: "Proporciona una lectura un poco más detallada que la versión gratuita, de unas 200-220 palabras.",
        premium: "Proporciona una lectura detallada, profunda y completa de al menos 300 palabras, explorando los matices de las líneas."
    }
}


export async function generatePalmReading(input: ReadingInput, language: Language, plan: SubscriptionPlan): Promise<string> {
  let contents;
  const p = prompts[language];
  const planModifier = plan === 'free' ? planModifiers[language].free : (plan === 'basic' ? planModifiers[language].basic : planModifiers[language].premium);
  
  if (input.handImage) {
    const imagePart = {
      inlineData: {
        mimeType: input.handImage.mimeType,
        data: input.handImage.data,
      },
    };
    const textPart = {
      text: `${p.base}\n\n${p.imageAnalysis}\n\n${p.style}\n\n${planModifier}`
    };
    contents = { parts: [imagePart, textPart] };
  } else if (input.lifeLine && input.headLine) {
    contents = `${p.base}\n\n${p.textAnalysis(input.lifeLine, input.headLine)}\n\n${p.style}\n\n${planModifier}`;
  } else {
    throw new Error("Invalid input provided for palm reading.");
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: {
        temperature: 0.7,
        topP: 0.9,
        topK: 40,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("The celestial connection is weak. Please try again.");
  }
}