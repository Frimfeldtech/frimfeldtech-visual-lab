import { Plan } from "./types";

export const plans: Plan[] = [
  {
    id: 'free',
    nameKey: 'planFreeName',
    price: 'Free',
    priceDetailsKey: '',
    features: [
      'planFreeFeature1',
      'planFreeFeature2',
      'planFreeFeature3',
    ],
  },
  {
    id: 'basic',
    nameKey: 'planBasicName',
    price: '$0.50',
    priceDetailsKey: 'planBasicPriceDetails',
    features: [
      'planBasicFeature1',
      'planBasicFeature2',
    ],
  },
  {
    id: '6-month',
    nameKey: 'plan6MonthName',
    price: '$2',
    priceDetailsKey: 'plan6MonthPriceDetails',
    features: [
      'plan6MonthFeature1',
      'plan6MonthFeature2',
      'plan6MonthFeature3',
    ],
  },
  {
    id: '1-year',
    nameKey: 'plan1YearName',
    price: '$5',
    priceDetailsKey: 'plan1YearPriceDetails',
    features: [
      'plan1YearFeature1',
      'plan1YearFeature2',
      'plan1YearFeature3',
    ],
  },
];