import React, { useRef, useEffect, useCallback, useState } from 'react';
import { CameraIcon, CloseIcon } from './icons';
import { useLanguage } from '../context/LanguageContext';

interface CameraViewProps {
  onCapture: (imageDataUrl: string) => void;
  onClose: () => void;
}

const CameraView: React.FC<CameraViewProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const { t } = useLanguage();

  const startCamera = useCallback(async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } else {
        setError(t('cameraNotSupportedError'));
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      setError(t('cameraAccessError'));
    }
  }, [t]);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
  }, []);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [startCamera, stopCamera]);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageDataUrl = canvas.toDataURL('image/jpeg');
        onCapture(imageDataUrl);
      }
    }
  };

  return (
    <div className="absolute inset-0 bg-brand-deep-purple/80 backdrop-blur-md flex flex-col items-center justify-center p-4 z-50 animate-fade-in">
       <button onClick={onClose} className="absolute top-5 right-5 text-white/70 hover:text-white transition-colors z-10" aria-label={t('closeCameraLabel')}>
          <CloseIcon className="w-8 h-8"/>
        </button>
      <div className="w-full max-w-lg aspect-square relative flex items-center justify-center">
        {error ? (
           <div className="text-center text-red-400 bg-red-900/50 p-4 rounded-lg">
             <h3 className="text-lg font-bold">{t('cameraErrorTitle')}</h3>
             <p>{error}</p>
           </div>
        ) : (
          <>
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover rounded-2xl shadow-2xl border-2 border-brand-light-purple/30" />
            <canvas ref={canvasRef} className="hidden" />
          </>
        )}
      </div>
      <div className="mt-8">
        <button 
          onClick={handleCapture} 
          disabled={!!error}
          className="w-20 h-20 bg-brand-gold rounded-full flex items-center justify-center shadow-lg transform hover:scale-105 transition-transform disabled:bg-gray-500 disabled:cursor-not-allowed"
          aria-label={t('capturePhotoLabel')}
        >
          <CameraIcon className="w-10 h-10 text-brand-deep-purple"/>
        </button>
      </div>
    </div>
  );
};

export default CameraView;