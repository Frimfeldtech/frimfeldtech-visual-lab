import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Language } from '../types';

interface WelcomeScreenProps {
  onStart: () => void;
}

const LanguageButton: React.FC<{
  onClick: () => void;
  children: React.ReactNode;
}> = ({ onClick, children }) => (
  <button
    onClick={onClick}
    className="w-full bg-brand-gold text-brand-deep-purple font-bold py-4 px-8 rounded-full shadow-lg hover:bg-yellow-300 transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-brand-gold focus:ring-opacity-50 text-lg"
  >
    {children}
  </button>
);

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart }) => {
  const { setLanguage, t } = useLanguage();

  const handleLanguageSelect = (lang: Language) => {
    setLanguage(lang);
    onStart();
  };

  return (
    <div className="text-center flex flex-col items-center justify-center h-full animate-fade-in py-8">
      <h2 className="text-3xl md:text-4xl font-bold text-white mb-3" style={{fontFamily: "'Playfair Display', serif"}}>
        {t('welcomeTitle')}
      </h2>
      <p className="text-base md:text-lg text-brand-light-gold/80 mb-10 max-w-md md:max-w-lg">
        {t('welcomeSubtitle')}
      </p>

      <div className="w-full max-w-xs sm:max-w-md">
        <div className="flex flex-col sm:flex-row gap-4">
          <LanguageButton onClick={() => handleLanguageSelect('en')}>
            English
          </LanguageButton>
          <LanguageButton onClick={() => handleLanguageSelect('es')}>
            Español
          </LanguageButton>
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;