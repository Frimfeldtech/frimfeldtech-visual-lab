
import React from 'react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="w-6 h-6 border-4 border-brand-deep-purple/20 border-t-brand-deep-purple rounded-full animate-spinner-rotate"></div>
  );
};
