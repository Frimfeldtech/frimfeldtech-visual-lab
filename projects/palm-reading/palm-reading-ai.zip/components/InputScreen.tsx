import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';
import { CameraIcon } from './icons';
import { useLanguage } from '../context/LanguageContext';

interface InputScreenProps {
  lifeLine: string;
  setLifeLine: (value: string) => void;
  headLine: string;
  setHeadLine: (value: string) => void;
  onGenerate: () => void;
  isLoading: boolean;
  error: string | null;
  handImage: string | null;
  onOpenCamera: () => void;
  onClearImage: () => void;
}

const InputScreen: React.FC<InputScreenProps> = ({
  lifeLine,
  setLifeLine,
  headLine,
  setHeadLine,
  onGenerate,
  isLoading,
  error,
  handImage,
  onOpenCamera,
  onClearImage
}) => {
  const { t } = useLanguage();
  const canGenerate = !isLoading && (!!handImage || (lifeLine.trim() !== '' && headLine.trim() !== ''));

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold text-center text-white mb-6" style={{fontFamily: "'Playfair Display', serif"}}>
        {t('inputTitle')}
      </h2>
      
      {handImage ? (
        <div className="my-6 text-center animate-fade-in">
          <p className="text-lg font-semibold text-brand-light-gold mb-3">{t('inputImagePreview')}</p>
          <div className="relative inline-block">
            <img src={handImage} alt={t('inputImageAlt')} className="rounded-lg border-2 border-brand-light-purple/50 mx-auto max-h-60 shadow-lg" />
          </div>
          <button onClick={onClearImage} className="mt-4 text-sm text-brand-gold hover:underline focus:outline-none focus:ring-2 focus:ring-brand-gold rounded">
            {t('inputUseText')}
          </button>
        </div>
      ) : (
        <>
          <div className="space-y-6">
            <div>
              <label htmlFor="lifeLine" className="block text-lg font-semibold text-brand-light-gold mb-2">
                {t('lifeLineLabel')}
              </label>
              <textarea
                id="lifeLine"
                value={lifeLine}
                onChange={(e) => setLifeLine(e.target.value)}
                placeholder={t('lifeLinePlaceholder')}
                rows={3}
                className="w-full bg-brand-deep-purple/50 border-2 border-brand-light-purple/50 rounded-lg p-3 text-white placeholder-brand-light-purple focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-colors duration-200 outline-none"
                disabled={isLoading}
              />
            </div>
            <div>
              <label htmlFor="headLine" className="block text-lg font-semibold text-brand-light-gold mb-2">
                {t('headLineLabel')}
              </label>
              <textarea
                id="headLine"
                value={headLine}
                onChange={(e) => setHeadLine(e.target.value)}
                placeholder={t('headLinePlaceholder')}
                rows={3}
                className="w-full bg-brand-deep-purple/50 border-2 border-brand-light-purple/50 rounded-lg p-3 text-white placeholder-brand-light-purple focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-colors duration-200 outline-none"
                disabled={isLoading}
              />
            </div>
          </div>

          <div className="my-6 flex items-center justify-center">
            <span className="flex-grow bg-brand-light-purple/30 h-px"></span>
            <span className="mx-4 text-brand-light-gold/80 font-serif">{t('orSeparator')}</span>
            <span className="flex-grow bg-brand-light-purple/30 h-px"></span>
          </div>
          
          <div className="text-center">
             <button onClick={onOpenCamera} disabled={isLoading} className="bg-transparent border-2 border-brand-light-purple text-brand-light-gold font-bold py-3 px-8 rounded-full hover:bg-brand-light-purple hover:text-white transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-brand-gold focus:ring-opacity-50 flex items-center justify-center gap-3 mx-auto">
                <CameraIcon className="w-5 h-5" />
                {t('scanHandButton')}
             </button>
          </div>
        </>
      )}
      
      {error && <p className="text-red-400 text-center mt-4">{error}</p>}

      <div className="text-center mt-8">
        <button
          onClick={onGenerate}
          disabled={!canGenerate}
          className="bg-brand-gold text-brand-deep-purple font-bold py-3 px-8 rounded-full shadow-lg hover:bg-yellow-300 transform hover:scale-105 transition-all duration-300 ease-in-out disabled:bg-brand-light-purple disabled:cursor-not-allowed disabled:scale-100 flex items-center justify-center min-w-[180px]"
        >
          {isLoading ? <LoadingSpinner /> : t('generateReadingButton')}
        </button>
      </div>
    </div>
  );
};

export default InputScreen;