import React, { useState, useEffect } from 'react';
import { SubscriptionPlan } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { plans } from '../constants';
import { LoadingSpinner } from './LoadingSpinner';
import { CloseIcon, CheckmarkIcon } from './icons';

interface PaymentModalProps {
  planId: SubscriptionPlan;
  onClose: () => void;
  onSuccess: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ planId, onClose, onSuccess }) => {
  const { t } = useLanguage();
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const plan = plans.find(p => p.id === planId);

  useEffect(() => {
    // Handle escape key to close modal
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2000);
  };
  
  if (!plan) return null;

  return (
    <div className="fixed inset-0 bg-brand-deep-purple/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-brand-purple rounded-2xl shadow-2xl w-full max-w-md border border-brand-light-purple/30 relative" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white transition-colors" aria-label={t('closeCameraLabel')}>
          <CloseIcon className="w-6 h-6"/>
        </button>

        {isSuccess ? (
            <div className="p-8 text-center flex flex-col items-center">
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mb-4">
                    <CheckmarkIcon className="w-10 h-10 text-green-400" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2" style={{fontFamily: "'Playfair Display', serif"}}>{t('paymentSuccessTitle')}</h2>
                <p className="text-brand-light-gold/80 mb-6">{t('paymentSuccessMessage')}</p>
                <button onClick={onSuccess} className="bg-brand-gold text-brand-deep-purple font-bold py-3 px-8 rounded-full shadow-lg hover:bg-yellow-300 transform hover:scale-105 transition-all duration-300 ease-in-out">
                    {t('startReadingButton')}
                </button>
            </div>
        ) : (
            <form onSubmit={handlePayment} className="p-8">
            <h2 className="text-2xl font-bold text-center text-white mb-6" style={{fontFamily: "'Playfair Display', serif"}}>{t('paymentTitle')}</h2>
            
            <div className="bg-brand-deep-purple/50 rounded-lg p-4 mb-6">
                <div className="flex justify-between items-center">
                <span className="text-lg text-brand-light-gold">{t(plan.nameKey)}</span>
                <span className="text-2xl font-bold text-white">{plan.price}</span>
                </div>
            </div>

            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-semibold text-brand-light-gold mb-1">{t('paymentCardNumberLabel')}</label>
                    <input type="text" placeholder={t('paymentCardNumberPlaceholder')} required className="w-full bg-brand-deep-purple/50 border-2 border-brand-light-purple/50 rounded-lg p-3 text-white placeholder-brand-light-purple focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-colors duration-200 outline-none" />
                </div>
                <div className="flex gap-4">
                <div className="w-1/2">
                    <label className="block text-sm font-semibold text-brand-light-gold mb-1">{t('paymentExpiryLabel')}</label>
                    <input type="text" placeholder={t('paymentExpiryPlaceholder')} required className="w-full bg-brand-deep-purple/50 border-2 border-brand-light-purple/50 rounded-lg p-3 text-white placeholder-brand-light-purple focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-colors duration-200 outline-none" />
                </div>
                <div className="w-1/2">
                    <label className="block text-sm font-semibold text-brand-light-gold mb-1">{t('paymentCvcLabel')}</label>
                    <input type="text" placeholder={t('paymentCvcPlaceholder')} required className="w-full bg-brand-deep-purple/50 border-2 border-brand-light-purple/50 rounded-lg p-3 text-white placeholder-brand-light-purple focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-colors duration-200 outline-none" />
                </div>
                </div>
            </div>
            
            <div className="mt-8">
                <button type="submit" disabled={isProcessing} className="w-full bg-brand-gold text-brand-deep-purple font-bold py-3 px-8 rounded-full shadow-lg hover:bg-yellow-300 transform hover:scale-105 transition-all duration-300 ease-in-out disabled:bg-brand-light-purple disabled:cursor-not-allowed flex items-center justify-center">
                {isProcessing ? (
                    <>
                        <LoadingSpinner />
                        <span className="ml-2">{t('paymentProcessing')}</span>
                    </>
                ) : (
                    t('payButton')
                )}
                </button>
            </div>
            </form>
        )}

      </div>
    </div>
  );
};

export default PaymentModal;
