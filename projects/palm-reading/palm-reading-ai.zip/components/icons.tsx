import React from 'react';

export const LogoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <defs>
      <linearGradient id="goldGradient" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#F7DE98" />
        <stop offset="50%" stopColor="#EAC15D" />
        <stop offset="100%" stopColor="#D4A237" />
      </linearGradient>
    </defs>
    <path
      d="M20.2,2H17.5C16.1,2,15,3.1,15,4.5v5.8c0,0.8-0.7,1.5-1.5,1.5S12,11.1,12,10.3V4.5 C12,3.1,10.9,2,9.5,2S7,3.1,7,4.5v7.2c0,0.8-0.7,1.5-1.5,1.5S4,12.5,4,11.7V6.5C4,5.1,2.9,4,1.5,4S-1,5.1-1,6.5v1.8 C-1,9.2-0.3,10,1,10.7c3.1,3.4,6.4,6.6,9.8,9.7c0.8,0.7,2.1,0.7,2.8,0c3.5-3,6.8-6.3,9.8-9.7c1.3-0.7,2-1.5,2-2.4v-3 C22,3.1,21.3,2,20.2,2z"
      transform="translate(1, 0)"
      fill="url(#goldGradient)"
    />
    <path
      d="M16.5,15.2c-2.3,1.8-5,2.8-8,2.8s-5.7-1-8-2.8c-1.4-1.1-2.5-2.5-3.2-4.1c1.8,0.7,3.8,1.1,5.8,1.1 c3.3,0,6.4-0.8,9.1-2.3c2-1.1,3.6-2.6,4.8-4.5c0.3,1.2,0.4,2.5,0.4,3.8C19.4,12.2,18.2,14,16.5,15.2z"
      transform="translate(2.5, 0)"
      fill="#000"
    />
    <circle cx="12" cy="14.5" r="2.5" fill="#000" />
  </svg>
);


export const CameraIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" />
    <circle cx="12" cy="13" r="3" />
  </svg>
);

export const CloseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

export const CheckmarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="3" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        {...props}>
        <path d="M20 6 9 17l-5-5" />
    </svg>
);