import React from 'react';
import { SubscriptionPlan } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { CheckmarkIcon } from './icons';
import { plans } from '../constants';

interface SubscriptionScreenProps {
  onSelectPlan: (plan: SubscriptionPlan) => void;
}

const SubscriptionScreen: React.FC<SubscriptionScreenProps> = ({ onSelectPlan }) => {
  const { t } = useLanguage();

  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold text-center text-white mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
        {t('subscriptionTitle')}
      </h2>
      <p className="text-center text-brand-light-gold/80 mb-8">{t('subscriptionSubtitle')}</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`bg-brand-deep-purple/50 rounded-xl p-6 border-2 transition-all duration-300 flex flex-col ${
              plan.id !== 'free'
                ? 'border-brand-gold/50 shadow-lg shadow-brand-gold/10'
                : 'border-brand-light-purple/50'
            }`}
          >
            <h3 className="text-2xl font-bold text-brand-gold font-serif h-16">{t(plan.nameKey)}</h3>
            <p className="text-4xl font-bold text-white my-4">
              {plan.price}
              {plan.id !== 'free' && <span className="text-base font-normal text-brand-light-gold/70 ml-1">{t(plan.priceDetailsKey)}</span>}
            </p>
            <ul className="space-y-3 text-brand-light-gold/90 mb-6 flex-grow">
              {plan.features.map((featureKey) => (
                <li key={featureKey} className="flex items-start">
                  <CheckmarkIcon className="w-5 h-5 text-brand-gold mr-3 mt-1 flex-shrink-0" />
                  <span>{t(featureKey)}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={() => onSelectPlan(plan.id)}
              className={`w-full font-bold py-3 px-8 rounded-full shadow-lg transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-opacity-50 ${
                plan.id === '6-month' || plan.id === '1-year'
                  ? 'bg-brand-gold text-brand-deep-purple hover:bg-yellow-300 focus:ring-brand-gold'
                  : 'bg-brand-light-purple text-white hover:bg-brand-light-purple/70 focus:ring-brand-light-purple'
              }`}
            >
              {t('choosePlanButton')}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SubscriptionScreen;