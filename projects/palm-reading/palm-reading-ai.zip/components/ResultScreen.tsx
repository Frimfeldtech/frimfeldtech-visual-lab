import React from 'react';
import { useLanguage } from '../context/LanguageContext';

interface ResultScreenProps {
  reading: string;
  onReset: () => void;
}

const ResultScreen: React.FC<ResultScreenProps> = ({ reading, onReset }) => {
  const { t } = useLanguage();
  return (
    <div className="animate-fade-in">
      <h2 className="text-3xl font-bold text-center text-white mb-6" style={{fontFamily: "'Playfair Display', serif"}}>
        {t('resultTitle')}
      </h2>
      <div className="bg-brand-deep-purple/50 p-6 rounded-lg max-h-64 sm:max-h-80 md:max-h-96 overflow-y-auto border border-brand-light-purple/30">
        <p className="text-brand-light-gold/90 whitespace-pre-wrap leading-relaxed">
          {reading}
        </p>
      </div>
      <div className="text-center mt-8">
        <button
          onClick={onReset}
          className="bg-transparent border-2 border-brand-gold text-brand-gold font-bold py-3 px-8 rounded-full hover:bg-brand-gold hover:text-brand-deep-purple transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-brand-gold focus:ring-opacity-50"
        >
          {t('readAnotherPalmButton')}
        </button>
      </div>
    </div>
  );
};

export default ResultScreen;